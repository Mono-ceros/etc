<?php
	$ID = $_POST["ID_Value"];
	$PW = $_POST["PW_Value"];


	error_reporting(E_ALL);
    ini_set("display_errors", 1);


	$conn=mysqli_connect("localhost","root","1234");
		
	mysqli_select_db($conn, "testtbl1");

    $query = "SELECT * from testtable where ID_Test='"$ID"' and PW_Test='"$PW"'";

	$res = mysqli_query($conn, $query);	
	
	$numrows = mysqli_num_rows($res);    

	//echo $numrows;

	if($numrows == 1)
	{
		$query = "SELECT NickName FROM testtable WHERE ID_Test='".$ID."'";

		$res = mysqli_query($conn, $query);	

		$row = mysqli_fetch_array($res);
		echo($row);
	}

	
    mysqli_close($conn);	

?>