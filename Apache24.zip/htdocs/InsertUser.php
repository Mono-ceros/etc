<?php

	$ID = $_POST["ID_Value"];
	$PW = $_POST["PW_Value"];
	$NN = $_POST["NN_Value"];


	error_reporting(E_ALL);
    ini_set("display_errors", 1);


	$conn=mysqli_connect("localhost","root","1234");
		

	mysqli_set_charset($conn,"utf8");
	
	mysqli_select_db($conn, "testtbl1");

	
	$query = "SELECT * FROM testtable WHERE ID_Test='".$ID."'";

	//echo $query;

	$res = mysqli_query($conn, $query);	
	
	$numrows = mysqli_num_rows($res);    

	//echo $numrows;

	if($numrows == 0)
	{
		$query = "INSERT INTO `testtable` (`ID_Test`, `PW_Test`, `NickName`) VALUES ('$ID', '$PW','$NN')";
			//echo $query;

		$res = mysqli_query($conn, $query);	

		if($res)
		{
			die("Create Account");
		}
		else
			die("Create error.");
	}
	else
		die("Duplicate ID exists.");
	


	mysqli_close($conn);	

?>