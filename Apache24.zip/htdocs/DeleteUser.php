<?php
	error_reporting(E_ALL);
    ini_set("display_errors", 1);


	$conn=mysqli_connect("localhost","root","1234");
		

	mysqli_set_charset($conn,"utf8");
	
	mysqli_select_db($conn, "testtbl1");
	
	$query = "SELECT * from testtable where ID_Test='".$ID."' and PW_Test='".$PW."'";

	$res = mysqli_query($conn, $query);	
	
	$numrows = mysqli_num_rows($res); 

	if($numrows == 1)
	{
		$query = "DELETE FROM testtable WHERE ID_Test='".$ID."'";

		$res = mysqli_query($conn, $query);	

		if($res)
		{
			die("Account Delete Complete. \n");
		}
		else
			die("Account Delete error. \n");
	}
	else
		die("Account does not exist. \n");
	


	mysqli_close($conn);	

?>